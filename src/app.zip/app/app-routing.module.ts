import { NgModule } from '@angular/core';
import { Routes, RouterModule, ActivatedRoute} from '@angular/router';

const routes: Routes = [];

@NgModule({
  imports: [RouterModule.forRoot(routes) ],
  exports: [RouterModule,ActivatedRoute]
})
export class AppRoutingModule { }
